"""Checks for the Week 3-5 midterm tools added in v0.7.0."""
import numpy as np
import pandas as pd
import pytest
from scipy import integrate, stats

import qrmlib as q


# ---------------- var / es ----------------
def test_es_t_matches_numeric_integral():
    fit = q.TFit(mu=0.001, sigma=0.02, nu=5.0, loglik=0.0, n=100)
    d = stats.t(5, loc=0.001, scale=0.02)
    for a in (0.05, 0.01):
        num = -integrate.quad(lambda x: x * d.pdf(x), -np.inf, d.ppf(a))[0] / a
        assert q.es_t(fit, a) == pytest.approx(num, rel=1e-8)
        assert q.es_t(fit, a) > q.var_t(fit, a)


def test_es_t_approaches_normal_for_large_nu():
    fit = q.TFit(0.0, 1.0, 1e7, 0.0, 10)
    assert q.es_t(fit, 0.05) == pytest.approx(q.es_normal(1.0, 0.05), rel=1e-5)


def test_risk_table_shape_and_order():
    x = np.random.default_rng(1).standard_t(4, 2000) * 0.01
    t = q.risk_table(x, alphas=(0.05, 0.01), value=1e6)
    assert list(t.index) == ["Normal", "Student t", "Historical"]
    assert list(t.columns) == ["VaR 5%", "ES 5%", "VaR 1%", "ES 1%"]
    assert (t["ES 1%"] > t["VaR 1%"]).all() and (t["VaR 1%"] > t["VaR 5%"]).all()


def test_var_es_table_adds_total():
    pnl = pd.DataFrame({"A": np.arange(100.0) - 50, "B": 50 - np.arange(100.0)})
    t = q.var_es_table(pnl, 0.05, total="Portfolio")
    assert t.loc["Portfolio", "VaR"] == pytest.approx(0.0)
    assert t.loc["A", "VaR"] == pytest.approx(46.0)          # 5th smallest of -50..49
    assert t.loc["A", "ES"] == pytest.approx(48.0)           # mean of -50..-46


def test_compare_normal_t_prefers_t_on_fat_tails():
    x = np.random.default_rng(2).standard_t(3, 3000)
    t = q.compare_normal_t(x)
    assert t.loc["Student t", "AICc"] < t.loc["Normal", "AICc"]
    assert t.loc["Student t", "BIC"] < t.loc["Normal", "BIC"]


# ---------------- ewma ----------------
def test_ew_correlation_and_mixed_cov():
    g = np.random.default_rng(3)
    x = pd.DataFrame(g.multivariate_normal([0, 0, 0], [[1, .5, .2], [.5, 2, .3], [.2, .3, 1.5]], 400),
                     columns=list("ABC"))
    c = q.ew_correlation(x, 0.97)
    assert np.allclose(np.diag(c), 1.0) and np.allclose(c, c.T)
    cov97 = q.ew_covariance(x, 0.97)
    assert c.loc["A", "B"] == pytest.approx(cov97[0, 1] / np.sqrt(cov97[0, 0] * cov97[1, 1]))
    cov, corr, sd = q.ew_mixed_covariance(x, 0.97, 0.94)
    assert np.allclose(np.diag(cov), np.diag(q.ew_covariance(x, 0.94)))
    assert np.allclose(q.cov_to_corr(cov)[0], corr)
    # same lambda for both -> ordinary EW covariance
    same, _, _ = q.ew_mixed_covariance(x, 0.94, 0.94)
    assert np.allclose(same, q.ew_covariance(x, 0.94))


# ---------------- psd repair on a covariance ----------------
def test_near_psd_cov_keeps_variances_and_fixes_eigs():
    corr = np.full((5, 5), 0.9)
    np.fill_diagonal(corr, 1.0)
    corr[0, 1] = corr[1, 0] = -0.5         # inconsistent -> not PSD
    sd = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
    cov = corr * np.outer(sd, sd)
    assert q.min_eigenvalue(cov) < 0
    for m in ("higham", "rj"):
        fixed = q.near_psd_cov(cov, m)
        assert np.allclose(np.diag(fixed), np.diag(cov))
        assert q.min_eigenvalue(fixed) > -1e-9
        q.chol_psd(fixed)
    h, r = q.near_psd_cov(cov, "higham"), q.near_psd_cov(cov, "rj")
    # Higham is the nearest correlation matrix -> closer in correlation space
    assert q.frobenius_distance(q.cov_to_corr(h)[0], corr) <= q.frobenius_distance(q.cov_to_corr(r)[0], corr) + 1e-9
    e = q.eigen_compare(original=cov, higham=h, rj=r)
    assert list(e.columns) == ["original", "higham", "rj"] and len(e) == 5


# ---------------- simulation ----------------
LECTURE_A = np.array([[4, 2, -2, 4], [2, 10, 5, -1], [-2, 5, 21, 0], [4, -1, 0, 15.0]])


def test_simulate_normal_cholesky_and_pca_recover_cov():
    for m in ("cholesky", "pca"):
        x = q.simulate_normal(LECTURE_A, 200_000, method=m, rng=1)
        assert np.allclose(np.cov(x.T), LECTURE_A, atol=0.25)


def test_pca_root_and_variance_explained():
    b = q.pca_root(LECTURE_A)
    assert np.allclose(b @ b.T, LECTURE_A)
    ve = q.variance_explained(LECTURE_A)
    assert ve["cum_pct"].iloc[-1] == pytest.approx(1.0)
    b2 = q.pca_root(LECTURE_A, pct_explained=0.75)
    assert b2.shape[1] == int((ve["cum_pct"] < 0.75).sum() + 1)


def test_simulate_mvt_covariance():
    r = np.array([[1, .6], [.6, 1]])
    x = q.simulate_mvt(r, 8, 300_000, rng=2)
    assert np.allclose(np.cov(x.T), r * 8 / 6, atol=0.03)


# ---------------- copula + portfolio ----------------
def _prices(n=750, seed=4):
    g = np.random.default_rng(seed)
    z = g.multivariate_normal([0, 0, 0], [[1, .7, .3], [.7, 1, .4], [.3, .4, 1]], n)
    r = 0.01 * z / np.sqrt(g.chisquare(5, (n, 1)) / 5)
    return pd.DataFrame(100 * np.cumprod(1 + r, axis=0), columns=["AAA", "BBB", "CCC"])


def test_shares_for_equal_weights():
    p = pd.Series({"A": 50.0, "B": 200.0})
    s = q.shares_for_weights(p, 100_000)
    assert s["A"] == pytest.approx(1000) and s["B"] == pytest.approx(250)
    assert q.position_values(s, p).sum() == pytest.approx(100_000)


def test_spearman_corr_matches_pandas():
    x = pd.DataFrame(np.random.default_rng(5).normal(size=(300, 3)))
    assert np.allclose(q.spearman_corr(x), x.corr(method="spearman"))


def test_portfolio_risk_methods_agree_roughly():
    prices = _prices()
    rets = q.return_calculate(prices)
    rets = rets - rets.mean()
    values = q.position_values(q.shares_for_weights(prices.iloc[-1], 100_000), prices.iloc[-1])
    hist = q.historical_risk(rets, values, 0.01)
    dn = q.delta_normal_risk(values, rets.cov(), 0.01)
    mc, _ = q.normal_mc_risk(values, rets.cov(), 0.01, 200_000, rng=1)
    gc, info = q.copula_risk(rets, values, 0.01, family="t", rng=1)
    tc, tinfo = q.copula_risk(rets, values, 0.01, family="t", copula="t", rng=1)
    for t in (hist, dn, mc, gc, tc):
        assert list(t.index) == ["AAA", "BBB", "CCC", "Portfolio"]
        assert (t["ES"] >= t["VaR"]).all()
        # diversification: portfolio risk below the sum of the parts
        assert t.loc["Portfolio", "VaR"] < t.loc[["AAA", "BBB", "CCC"], "VaR"].sum()
    assert np.allclose(mc["VaR"], dn["VaR"], rtol=0.03)
    assert np.allclose(gc["VaR"], hist["VaR"], rtol=0.25)
    assert set(info["params"]["kind"]) == {"t"}
    assert tinfo["copula_fit"].nu > 2
    assert np.allclose(np.diag(info["R"]), 1.0)
    both = q.compare_methods({"Gaussian copula": gc, "Historical": hist})
    assert both.shape == (4, 4)
