"""Assignment 1 functions inside the combined library."""
import numpy as np
import pandas as pd
import pytest
from scipy import stats

from qrmlib import (first4_moments, quantile_exceedance, aicc, largest_gap,
                    conditional_normal, conditional_line, band_inside, coverage_by_bucket,
                    to_latex_grid)
from qrmlib import ols_se as ols, mle_regression_normal as mle_normal, mle_regression_t as mle_t


def excess_kurtosis(x):
    return first4_moments(x)[3] - 3


def fit_normal_mom(x):
    m, v, _, _ = first4_moments(x)
    return stats.norm(m, np.sqrt(v))


def test_moments_match_scipy():
    x = np.random.default_rng(1).standard_t(5, 2000)
    m, v, s, k = first4_moments(x)
    assert m == pytest.approx(x.mean())
    assert v == pytest.approx(x.var(ddof=1))
    assert s == pytest.approx(stats.skew(x))
    assert k == pytest.approx(stats.kurtosis(x, fisher=False))
    assert excess_kurtosis(x) == pytest.approx(stats.kurtosis(x))


def test_quantile_exceedance_on_normal_data():
    x = np.random.default_rng(2).normal(0, 1, 100_000)
    q, below, expected = quantile_exceedance(x, fit_normal_mom(x), 0.01)
    assert expected == 1000
    assert abs(below - expected) < 120


def test_ols_and_mle_recover_line():
    g = np.random.default_rng(3)
    x = g.normal(size=500)
    y = 1.0 + 2.0 * x + g.normal(0, 0.5, 500)
    o = ols(x, y)
    assert o.alpha == pytest.approx(1.0, abs=0.1) and o.beta == pytest.approx(2.0, abs=0.1)
    assert o.se_beta == pytest.approx(np.sqrt(o.s ** 2 / np.sum((x - x.mean()) ** 2)))
    n = mle_normal(x, y)
    assert n.beta == pytest.approx(o.beta, abs=1e-5)
    assert n.scale == pytest.approx(o.s * np.sqrt((500 - 2) / 500), rel=1e-4)


def test_t_errors_preferred_when_fat_tailed():
    g = np.random.default_rng(4)
    x = g.normal(size=400)
    y = 0.5 + x + 0.5 * g.standard_t(3, 400)
    assert mle_t(x, y).aicc < mle_normal(x, y).aicc


def test_aicc_formula():
    assert aicc(-100.0, 3, 50) == pytest.approx(2 * 3 + 200 + 24 / 46)


def test_largest_gap_upper_triangle():
    a = pd.DataFrame([[1, .5, .1], [.5, 1, .2], [.1, .2, 1]], index=list("abc"), columns=list("abc"))
    b = a.copy()
    b.loc["a", "c"] = b.loc["c", "a"] = .6
    assert largest_gap(a, b) == (("a", "c"), pytest.approx(0.5))


def test_conditional_normal_matches_bivariate_line():
    df = pd.DataFrame(np.random.default_rng(5).multivariate_normal([1, 2], [[1, .8], [.8, 2]], 5000),
                      columns=["x1", "x2"])
    line = conditional_line(df, "x1", "x2")
    mu, S = df.mean().to_numpy(), df.cov().to_numpy()
    m_bar, s_bar = conditional_normal(mu, S, known=[0], a=[1.7])
    assert m_bar[0] == pytest.approx(line.mean(1.7))
    assert s_bar[0, 0] == pytest.approx(line.cond_var)
    inside = band_inside(line, df.x1, df.x2)
    assert inside.mean() == pytest.approx(0.95, abs=0.01)
    t = coverage_by_bucket(line, df.x1, inside)
    assert t["n"].sum() == 5000


def test_latex_grid_shape():
    s = to_latex_grid(pd.DataFrame([[1.0]], index=["a"], columns=["a"]))
    assert s.count(r"\hline") == 3 and "1.0000" in s
