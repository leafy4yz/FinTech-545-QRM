"""
qrmlib against the course test cases (Tests.xlsx / test_setup.jl), using the
input and reference output CSVs from the "Tests 1" folder (copied into
tests/course_data).  These pin the class conventions: EW mean, n - 1 normal
sigma, Higham / near_psd on covariances, t VaR / ES, copula VaR.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import qrmlib as q

D = Path(__file__).resolve().parent / "course_data"


def load(name):
    return pd.read_csv(D / name)


def close(a, b, tol):
    return np.allclose(np.asarray(a, float), np.asarray(b, float), atol=tol, rtol=0)


def test_1_missing_pairwise():
    x = load("test1.csv")
    assert close(q.cov_pairwise(x), load("testout_1.3.csv"), 1e-12)
    assert close(q.corr_pairwise(x), load("testout_1.4.csv"), 1e-12)


def test_2_ew():
    x = load("test2.csv")
    assert close(q.ew_covariance(x, 0.97), load("testout_2.1.csv"), 1e-12)
    assert close(q.ew_correlation(x, 0.94), load("testout_2.2.csv"), 1e-12)
    cov, _, _ = q.ew_mixed_covariance(x, lam_corr=0.94, lam_var=0.97)
    assert close(cov, load("testout_2.3.csv"), 1e-12)


def test_3_psd_repairs():
    c13, c14 = load("testout_1.3.csv"), load("testout_1.4.csv")
    assert close(q.near_psd_cov(c13, "rj"), load("testout_3.1.csv"), 1e-10)
    assert close(q.near_psd_cov(c14, "rj"), load("testout_3.2.csv"), 1e-10)
    assert close(q.near_psd_cov(c13, "higham"), load("testout_3.3.csv"), 1e-8)
    assert close(q.near_psd_cov(c14, "higham"), load("testout_3.4.csv"), 1e-8)


def test_4_chol_psd():
    assert close(q.chol_psd(load("testout_3.1.csv")), load("testout_4.1.csv"), 1e-12)


def test_5_pca_simulation_covariance():
    s = load("test5_2.csv")
    sim = q.simulate_normal(s, 100_000, method="pca", pct_explained=0.99, rng=1)
    assert close(np.cov(np.asarray(sim).T), s, 0.01)


def test_6_returns():
    r = q.return_calculate(load("test6.csv"), "DISCRETE", date_column="Date").drop(columns="Date")
    assert close(r, load("testout_6.1.csv").drop(columns="Date"), 1e-12)


def test_7_fits():
    x1, x2 = load("test7_1.csv").x1, load("test7_2.csv").x1
    ref = load("testout_7.1.csv").iloc[0]
    assert x1.mean() == pytest.approx(ref.mu) and x1.std(ddof=1) == pytest.approx(ref.sigma)
    tf, ref = q.fit_t(x2), load("testout_7.2.csv").iloc[0]
    assert tf.mu == pytest.approx(ref.mu, abs=1e-5)
    assert tf.sigma == pytest.approx(ref.sigma, abs=1e-5)
    assert tf.nu == pytest.approx(ref.nu, abs=1e-3)


@pytest.mark.parametrize("ref_file, data, model, col", [
    ("testout8_1.csv", "test7_1.csv", "Normal", "VaR 5%"),
    ("testout8_2.csv", "test7_2.csv", "Student t", "VaR 5%"),
    ("testout8_4.csv", "test7_1.csv", "Normal", "ES 5%"),
    ("testout8_5.csv", "test7_2.csv", "Student t", "ES 5%"),
])
def test_8_var_es(ref_file, data, model, col):
    x = load(data).x1
    ref = load(ref_file).iloc[0].to_numpy()
    absolute = q.risk_table(x, (0.05,)).loc[model, col]
    from_mean = q.risk_table(x, (0.05,), from_mean=True).loc[model, col]
    assert absolute == pytest.approx(ref[0], abs=1e-6)
    assert from_mean == pytest.approx(ref[1], abs=1e-6)


def test_8_6_simulated_t_es():
    tf = q.fit_t(load("test7_2.csv").x1)
    g = np.random.default_rng(9)
    sim = tf.mu + tf.sigma * g.standard_t(tf.nu, 1_000_000)
    es_sim = q.es_historical(sim, 0.05)
    # the course figure is itself a simulation, so compare loosely; the closed
    # form is the anchor
    assert es_sim == pytest.approx(q.es_t(tf, 0.05), rel=0.02)
    assert es_sim == pytest.approx(load("testout8_6.csv").iloc[0, 0], rel=0.03)


def test_fit_t_finds_global_optimum():
    # L-BFGS-B alone stops at nu ~ 12 (loglik 465.24); the optimum is nu ~ 4.8
    tf = q.fit_t(load("test9_1_returns.csv").B)
    assert tf.loglik > 466.31
    assert 4.5 < tf.nu < 5.1


def test_9_1_copula_var_es():
    r = load("test9_1_returns.csv")
    ref = load("testout9_1.csv").set_index("Stock")
    t, _ = q.copula_risk(r, pd.Series({"A": 2000.0, "B": 3000.0}), 0.05,
                         family={"A": "normal", "B": "t"}, rng=91)
    for ours, theirs in (("A", "A"), ("B", "B"), ("Portfolio", "Total")):
        assert t.loc[ours, "VaR"] == pytest.approx(ref.loc[theirs, "VaR95"], rel=0.02)
        assert t.loc[ours, "ES"] == pytest.approx(ref.loc[theirs, "ES95"], rel=0.025)
